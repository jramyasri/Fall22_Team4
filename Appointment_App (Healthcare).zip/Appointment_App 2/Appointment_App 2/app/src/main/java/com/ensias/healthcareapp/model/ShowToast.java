package com.ensias.healthcareapp.model;

public interface ShowToast {

    public void onShowToast (String message);

}
