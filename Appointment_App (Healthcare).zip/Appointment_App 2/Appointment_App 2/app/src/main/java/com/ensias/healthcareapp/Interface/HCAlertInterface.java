package com.ensias.healthcareapp.Interface;

public interface HCAlertInterface {
    public void onClickLister();
}
