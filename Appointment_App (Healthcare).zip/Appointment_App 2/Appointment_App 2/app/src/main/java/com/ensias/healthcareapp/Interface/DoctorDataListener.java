package com.ensias.healthcareapp.Interface;

import com.ensias.healthcareapp.model.Doctor;

public interface DoctorDataListener {
    public void getDoctor(Doctor doctor);
}
